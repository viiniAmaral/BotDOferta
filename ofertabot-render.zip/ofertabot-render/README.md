# 🥦 OfertaBot — Deploy no Render

## Passo a passo pelo celular (10 minutos)

---

### 1. Criar conta no GitHub
Acesse **github.com** → Sign up → conta gratuita

---

### 2. Criar repositório no GitHub

1. Clique em **"+"** no topo → **New repository**
2. Nome: `ofertabot`
3. Marque **Private**
4. Clique em **Create repository**

---

### 3. Subir os arquivos

Na página do repositório vazio, clique em **"uploading an existing file"**

Faça upload de todos os arquivos desta pasta:
- `server.js`
- `package.json`
- `render.yaml`
- `.gitignore`
- pasta `public/` com o `index.html`

Clique em **Commit changes**

---

### 4. Criar conta no Render

Acesse **render.com** → **Get Started for Free** → entre com sua conta GitHub

---

### 5. Criar o banco PostgreSQL

1. No dashboard do Render, clique em **New +** → **PostgreSQL**
2. Nome: `ofertabot-db`
3. Plano: **Free**
4. Região: **Oregon (US West)** ou a mais próxima disponível
5. Clique em **Create Database**
6. Aguarde ficar verde (2-3 minutos)

---

### 6. Criar o Web Service

1. Clique em **New +** → **Web Service**
2. Conecte ao repositório `ofertabot` do GitHub
3. Preencha:
   - **Name:** `ofertabot`
   - **Runtime:** `Node`
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Plan:** Free
4. Em **Environment Variables**, clique em **Add from Database**
   - Selecione `ofertabot-db`
   - Isso adiciona `DATABASE_URL` automaticamente
5. Clique em **Create Web Service**

---

### 7. Aguardar o deploy

O Render vai instalar as dependências e iniciar o servidor.
Quando aparecer **"Live"** com bolinha verde, seu app está no ar!

O link será algo como: `https://ofertabot.onrender.com`

---

### 8. Configurar a chave Groq

Adicione a variável de ambiente no Render:

1. No painel do Web Service → **Environment**
2. Adicione:
   - Key: `GROQ_API_KEY`  
   - Value: sua chave `gsk_...`
3. Clique em **Save Changes** (o servidor vai reiniciar)

---

## ⚠️ Limitações do plano gratuito

| Item | Limite |
|------|--------|
| Web Service | Dorme após 15 min sem uso (30s para acordar) |
| PostgreSQL | 1GB de dados, 90 dias de uso gratuito |
| Bandwidth | 100GB/mês |

Para uso pessoal/familiar, o plano gratuito é mais que suficiente.

---

## 🔄 Atualizar o app

Sempre que quiser atualizar:
1. Edite os arquivos no GitHub
2. O Render faz deploy automático em ~2 minutos

---

## 💡 Dica: evitar o sleep

Para o app não dormir, use o **UptimeRobot** (gratuito):
1. Acesse **uptimerobot.com**
2. Adicione um monitor HTTP para a URL do seu app
3. Intervalo: 5 minutos
4. O app ficará sempre acordado!
