const express  = require("express");
const multer   = require("multer");
const fetch    = require("node-fetch");
const path     = require("path");
const os       = require("os");
const Database = require("better-sqlite3");

const app    = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 30 * 1024 * 1024 } });
app.use(express.json({ limit: "50mb" }));
app.use(express.static(path.join(__dirname, "public")));

// ── Banco SQLite ──────────────────────────────────────────────────────────────
const db = new Database(path.join(__dirname, "ofertabot.db"));
db.exec(`
  CREATE TABLE IF NOT EXISTS stores (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL UNIQUE,
    color      TEXT NOT NULL DEFAULT '#1f7a4a',
    logo       TEXT,
    created_at TEXT DEFAULT (datetime('now','localtime'))
  );

  CREATE TABLE IF NOT EXISTS markets (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    market     TEXT NOT NULL,
    color      TEXT NOT NULL,
    date       TEXT NOT NULL,
    tiles      INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now','localtime')),
    date_end   TEXT
  );
  CREATE TABLE IF NOT EXISTS items (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    market_id INTEGER NOT NULL REFERENCES markets(id) ON DELETE CASCADE,
    name      TEXT NOT NULL,
    price     TEXT NOT NULL,
    original  TEXT,
    category  TEXT,
    promo     TEXT,
    image     TEXT,
    fav       INTEGER DEFAULT 0
  );
`);
// migrações seguras
["date_end"].forEach(col => {
  try { db.exec(`ALTER TABLE markets ADD COLUMN ${col} TEXT`); } catch(_) {}
});
["promo","image"].forEach(col => {
  try { db.exec(`ALTER TABLE items ADD COLUMN ${col} TEXT`); } catch(_) {}
});

function getLocalIP() {
  const nets = os.networkInterfaces();
  for (const n of Object.keys(nets))
    for (const net of nets[n])
      if (net.family === "IPv4" && !net.internal) return net.address;
  return "localhost";
}

// ── Tiling adaptativo ─────────────────────────────────────────────────────────
async function splitImageToTiles(buffer) {
  const sharp = require("sharp");
  const meta  = await sharp(buffer).metadata();
  const W = meta.width, H = meta.height;

  const isDoublePage = W > H * 1.3;
  const isDense      = W * H > 2_000_000;

  let cols, rows;
  if (isDoublePage)  { cols = 2; rows = isDense ? 4 : 3; }
  else               { cols = 1; rows = isDense ? 3 : (H > 1200 ? 2 : 1); }

  const tileW = Math.ceil(W / cols);
  const tileH = Math.ceil(H / rows);
  const ov    = 0.08;
  const tiles = [];

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const left   = Math.max(0, Math.floor(c * tileW - tileW * ov));
      const top    = Math.max(0, Math.floor(r * tileH - tileH * ov));
      const width  = Math.min(tileW + Math.ceil(tileW * ov * 2), W - left);
      const height = Math.min(tileH + Math.ceil(tileH * ov * 2), H - top);

      // Redimensiona para max 1200px mantendo proporção
      let tileBuf = await sharp(buffer).extract({ left, top, width, height }).toBuffer();
      const tileMeta = await sharp(tileBuf).metadata();
      const scale = tileMeta.width > 1200 ? 1200 / tileMeta.width : 1;
      if (scale < 1) {
        tileBuf = await sharp(tileBuf)
          .resize({ width: Math.round(tileMeta.width * scale) })
          .toBuffer();
      }
      const finalMeta = await sharp(tileBuf).metadata();

      tiles.push({
        base64: tileBuf.toString("base64"),
        buffer: tileBuf,
        width:  finalMeta.width,
        height: finalMeta.height,
        index:  r * cols + c,
        total:  rows * cols,
        row: r, col: c, cols, rows,
      });
    }
  }
  return tiles;
}

// ── Recorta a imagem do produto a partir do bbox ───────────────────────────────
async function cropProductImage(tileBuffer, tileW, tileH, bbox) {
  try {
    const sharp = require("sharp");
    // bbox em percentual [x1, y1, x2, y2] — clamp entre 0 e 1
    const [x1r, y1r, x2r, y2r] = bbox.map(v => Math.min(1, Math.max(0, v)));
    const left   = Math.round(x1r * tileW);
    const top    = Math.round(y1r * tileH);
    const width  = Math.max(10, Math.round((x2r - x1r) * tileW));
    const height = Math.max(10, Math.round((y2r - y1r) * tileH));

    // Não cortar região inválida
    if (left + width > tileW || top + height > tileH) return null;

    // Adiciona padding de 3% ao redor do produto
    const padX = Math.round(width  * 0.03);
    const padY = Math.round(height * 0.03);
    const safeL = Math.max(0, left   - padX);
    const safeT = Math.max(0, top    - padY);
    const safeW = Math.min(tileW - safeL, width  + padX * 2);
    const safeH = Math.min(tileH - safeT, height + padY * 2);

    const cropped = await sharp(tileBuffer)
      .extract({ left: safeL, top: safeT, width: safeW, height: safeH })
      .resize({ width: 300, withoutEnlargement: true }) // max 300px largura
      .jpeg({ quality: 82 })
      .toBuffer();

    return "data:image/jpeg;base64," + cropped.toString("base64");
  } catch(_) { return null; }
}

// ── Prompt com instrução de bbox ──────────────────────────────────────────────
function buildPrompt(index, total, row, col, cols, rows) {
  const pos = total > 1
    ? `Esta é a seção ${index+1} de ${total} de um folheto de supermercado (linha ${row+1}/${rows}, coluna ${col+1}/${cols}).`
    : "Este é um folheto de supermercado brasileiro.";

  return `${pos}

INSTRUÇÕES:

1. Extraia TODOS os produtos com preço visível. Não pule nenhum.

2. Para cada produto, retorne o campo "bbox": as coordenadas do card do produto
   como [x1, y1, x2, y2] em valores de 0.0 a 1.0 (proporção da imagem).
   - x1,y1 = canto superior esquerdo do card do produto
   - x2,y2 = canto inferior direito do card do produto
   - Seja preciso: inclua a imagem do produto + preço + nome no bbox
   - Se não conseguir localizar, use [0.0, 0.0, 0.0, 0.0]

3. PREÇOS:
   - "price" = preço promocional (após "PAGUE SÓ", "OFERTA", maior destaque)
   - "original" = preço riscado/anterior (se visível, senão estime +25%)
   - "promo" = promoção especial se houver: "Leve 3 Pague 2", "Pack c/12", etc.

4. "name" = marca + produto + gramatura/quantidade quando visível

5. "category" = Carnes|Aves|Peixes|Frios|Laticínios|Padaria|Graos|Massas|Hortifruti|Bebidas|Cervejas|Higiene|Limpeza|Congelados|Mercearia|Outros

Retorne APENAS JSON puro sem markdown:
{"items":[{"name":"...","price":"R$ X,XX","original":"R$ X,XX","category":"...","promo":"","bbox":[x1,y1,x2,y2]}]}
Se não encontrar produtos: {"items":[]}`;
}

// ── Analisa tile e retorna itens com bbox ─────────────────────────────────────
async function analyzeTile(tile, mimeType, apiKey) {
  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "content-type": "application/json", "authorization": `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: "meta-llama/llama-4-scout-17b-16e-instruct",
      max_tokens: 4096,
      temperature: 0.05,
      messages: [
        {
          role: "system",
          content: "Você é um especialista em leitura de folhetos de supermercado brasileiro. Extraia todos os produtos com preço e retorne suas coordenadas bbox precisas. Responda sempre com JSON puro."
        },
        {
          role: "user",
          content: [
            { type: "image_url", image_url: { url: `data:${mimeType};base64,${tile.base64}` } },
            { type: "text",      text: buildPrompt(tile.index, tile.total, tile.row, tile.col, tile.cols, tile.rows) }
          ]
        }
      ]
    })
  });

  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error(e?.error?.message || `HTTP ${res.status}`);
  }

  const data  = await res.json();
  const raw   = data.choices?.[0]?.message?.content?.trim() || "{}";
  const clean = raw.replace(/^```[a-z]*\n?/i,"").replace(/\n?```$/,"").trim();

  let items = [];
  try { items = JSON.parse(clean).items || []; } catch(_) { return []; }

  // Para cada item, recorta a imagem do produto usando o bbox
  const withImages = await Promise.all(items.map(async item => {
    let image = null;
    if (item.bbox && Array.isArray(item.bbox) && item.bbox.length === 4) {
      const [x1, y1, x2, y2] = item.bbox;
      if (x2 > x1 && y2 > y1) {
        image = await cropProductImage(tile.buffer, tile.width, tile.height, item.bbox);
      }
    }
    return { ...item, image };
  }));

  return withImages;
}

// ── Deduplicação ──────────────────────────────────────────────────────────────
function dedup(items) {
  const seen = new Map();
  const result = [];
  for (const item of items) {
    const key = item.name.toLowerCase().replace(/[^a-záéíóúàâêôãõç0-9]/g,"").substring(0, 25);
    if (!seen.has(key)) {
      seen.set(key, result.length);
      result.push(item);
    } else {
      const idx = seen.get(key);
      if (item.promo  && !result[idx].promo)  result[idx].promo  = item.promo;
      if (item.image  && !result[idx].image)  result[idx].image  = item.image;
    }
  }
  return result;
}

// ── POST /api/analyze ─────────────────────────────────────────────────────────
app.post("/api/analyze", upload.single("image"), async (req, res) => {
  try {
    const apiKey = req.headers["x-api-key"];
    if (!apiKey) return res.status(401).json({ error: "Chave de API ausente." });
    if (!req.file) return res.status(400).json({ error: "Nenhuma imagem enviada." });

    const typeMap  = { "image/jpeg":"image/jpeg","image/jpg":"image/jpeg","image/png":"image/png","image/webp":"image/webp" };
    const mimeType = typeMap[req.file.mimetype] || "image/jpeg";
    const market    = req.body.market    || "Mercado";
    const color     = req.body.color     || "#6366f1";
    const dateEnd    = req.body.date_end   || null;
    const promoType  = req.body.promo_type || "day";

    const tiles = await splitImageToTiles(req.file.buffer);

    // Processa lotes de 2 tiles
    const allItems = [];
    for (let i = 0; i < tiles.length; i += 2) {
      const batch   = tiles.slice(i, i + 2);
      const results = await Promise.all(batch.map(t => analyzeTile(t, mimeType, apiKey)));
      results.forEach(r => allItems.push(...r));
      if (i + 2 < tiles.length) await new Promise(r => setTimeout(r, 800));
    }

    const items    = dedup(allItems);
    const date     = req.body.date_start ? req.body.date_start : new Date().toLocaleDateString("pt-BR");

    const insM = db.prepare("INSERT INTO markets (market, color, date, date_end, tiles) VALUES (?, ?, ?, ?, ?)");
    const insI = db.prepare("INSERT INTO items (market_id, name, price, original, category, promo, image) VALUES (?, ?, ?, ?, ?, ?, ?)");

    const marketId = db.transaction(() => {
      const { lastInsertRowid } = insM.run(market, color, date, dateEnd, tiles.length);
      for (const item of items)
        insI.run(lastInsertRowid, item.name, item.price, item.original||"", item.category||"Outros", item.promo||"", item.image||null);
      return lastInsertRowid;
    })();

    res.json({
      id: marketId, market, color, date, date_end: dateEnd, promo_type: promoType,
      tiles: tiles.length,
      items: items.map(i => ({ ...i, fav: false })),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/markets ──────────────────────────────────────────────────────────
app.get("/api/markets", (req, res) => {
  try {
    const markets  = db.prepare("SELECT * FROM markets ORDER BY created_at DESC").all();
    const getItems = db.prepare("SELECT * FROM items WHERE market_id = ?");
    res.json(markets.map(m => ({
      id: m.id, market: m.market, color: m.color, date: m.date, date_end: m.date_end||null, tiles: m.tiles,
      items: getItems.all(m.id).map(i => ({ ...i, fav: i.fav === 1 })),
    })));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── PATCH /api/items/:id/fav ──────────────────────────────────────────────────
app.patch("/api/items/:id/fav", (req, res) => {
  try {
    db.prepare("UPDATE items SET fav = ? WHERE id = ?").run(req.body.fav ? 1 : 0, req.params.id);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── DELETE /api/markets/:id ───────────────────────────────────────────────────
app.delete("/api/markets/:id", (req, res) => {
  try {
    db.prepare("DELETE FROM markets WHERE id = ?").run(req.params.id);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── GET /api/stores ──────────────────────────────────────────────────────────
app.get("/api/stores", (req, res) => {
  try {
    res.json(db.prepare("SELECT * FROM stores ORDER BY name ASC").all());
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── POST /api/stores ──────────────────────────────────────────────────────────
app.post("/api/stores", (req, res) => {
  try {
    const { name, color } = req.body;
    if (!name?.trim()) return res.status(400).json({ error: "Nome obrigatório." });
    const { lastInsertRowid } = db.prepare(
      "INSERT INTO stores (name, color) VALUES (?, ?)"
    ).run(name.trim(), color || "#1f7a4a");
    const store = db.prepare("SELECT * FROM stores WHERE id = ?").get(lastInsertRowid);
    res.json(store);
  } catch (err) {
    if (err.message.includes("UNIQUE")) return res.status(409).json({ error: "Mercado já cadastrado." });
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/stores/:id ────────────────────────────────────────────────────
app.delete("/api/stores/:id", (req, res) => {
  try {
    db.prepare("DELETE FROM stores WHERE id = ?").run(req.params.id);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── PATCH /api/stores/:id ─────────────────────────────────────────────────────
app.patch("/api/stores/:id", (req, res) => {
  try {
    const { name, color } = req.body;
    db.prepare("UPDATE stores SET name = ?, color = ? WHERE id = ?")
      .run(name.trim(), color, req.params.id);
    res.json(db.prepare("SELECT * FROM stores WHERE id = ?").get(req.params.id));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const PORT = 3000, IP = getLocalIP();
app.listen(PORT, "0.0.0.0", () => {
  const total = db.prepare("SELECT COUNT(*) as n FROM markets").get().n;
  console.log("\n╔══════════════════════════════════════════╗");
  console.log("║           🥦 OfertaBot Local             ║");
  console.log("╠══════════════════════════════════════════╣");
  console.log(`║  Computador:  http://localhost:${PORT}       ║`);
  console.log(`║  Celular:     http://${IP}:${PORT}    ║`);
  console.log("╠══════════════════════════════════════════╣");
  console.log(`║  Banco: ${String(total).padEnd(3)} folheto(s) persistido(s)      ║`);
  console.log("╚══════════════════════════════════════════╝\n");
});
